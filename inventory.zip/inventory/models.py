from django.db import models
from business.models import Business
from catalog.models import Category
from django.conf import settings

from django.utils import timezone
from decimal import Decimal
from django.db import transaction
from django.contrib.auth.models import User
import uuid
from django.utils.text import slugify
from decimal import Decimal


MOVEMENT_TYPES = (

    ("opening", "Opening Stock"),

    ("purchase", "Purchase"),

    ("sale", "Sale"),

    ("return", "Sales Return"),

    ("supplier_return", "Supplier Return"),

    ("restock", "Restock"),

    ("adjustment", "Stock Adjustment"),

    ("damage", "Damaged"),

    ("expired", "Expired"),

    ("transfer_in", "Transfer In"),

    ("transfer_out", "Transfer Out"),

    ("production", "Production"),

)

DIRECTION = (

    ("IN","Stock In"),

    ("OUT","Stock Out"),

)

UNIT_CHOICES = (
    ("pcs", "Pieces"),
    ("box", "Box"),
    ("pack", "Pack"),
    ("kg", "Kilogram"),
    ("g", "Gram"),
    ("ltr", "Litre"),
    ("ml", "Millilitre"),
    ("carton", "Carton"),
    ("bag", "Bag"),
    ("roll", "Roll"),
)

STATUS_CHOICES = (
    ("active", "Active"),
    ("inactive", "Inactive"),
)


class Inventory(models.Model):
    business = models.ForeignKey(Business, on_delete=models.CASCADE)
    product_name = models.CharField(max_length=50)
    category = models.ForeignKey(
        Category,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="products",
    )
    stock_quantity = models.IntegerField(default=0)
    cost_price = models.DecimalField(max_digits=10, decimal_places=2)
    selling_price = models.DecimalField(max_digits=10, decimal_places=2)

    # ==========================================
    # PRODUCT MASTER
    # ==========================================
    sku = models.CharField(max_length=50, unique=True, blank=True, null=True)
    barcode = models.CharField(max_length=120, blank=True, null=True, db_index=True)
    qr_code = models.CharField(max_length=120, blank=True, null=True)
    brand = models.CharField(max_length=120, blank=True)
    unit = models.CharField(max_length=20, choices=UNIT_CHOICES, default="pcs")
    description = models.TextField(blank=True)
    minimum_stock = models.PositiveIntegerField(default=0)
    maximum_stock = models.PositiveIntegerField(default=0)
    reorder_level = models.PositiveIntegerField(default=0)
    reorder_quantity = models.PositiveIntegerField(default=0)
    track_stock = models.BooleanField(default=True)
    featured = models.BooleanField(default=False)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="active")
    product_image = models.ImageField(upload_to="product/", blank=True, null=True)
    updated_at = models.DateTimeField(auto_now=True)

    def save(self, *args, **kwargs):
        if not self.sku:
            self.sku = f"SKU-{uuid.uuid4().hex[:8].upper()}"

        if not self.barcode:
            self.barcode = self.sku.replace("SKU-", "")

        if not self.qr_code:
            self.qr_code = self.barcode

        super().save(*args, **kwargs)

    @property
    def is_low_stock(self):
        return self.stock_quantity <= self.minimum_stock

    @property
    def is_out_of_stock(self):
        return self.stock_quantity <= 0

    @property
    def profit(self):
        return self.selling_price - self.cost_price

    @property
    def stock_value(self):
        return self.stock_quantity * self.cost_price

    @property
    def retail_value(self):
        return self.stock_quantity * self.selling_price

    def __str__(self):
        return f"{self.product_name} ({self.sku})"


class Supplier(models.Model):

    business = models.ForeignKey('business.Business', on_delete=models.CASCADE)
    name = models.CharField(max_length=50)
    phone = models.CharField(max_length=30, blank=True, null=True)
    email = models.EmailField(blank=True, null=True)
    address = models.TextField(blank=True, null=True)
    country = models.CharField(max_length=50, blank=True, null=True)
    is_active = models.BooleanField(default=True)
    notes = models.TextField(blank=True, null=True)

    # =========================
    # FINANCIAL (ERP CORE)
    # =========================
    total_purchases = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=Decimal("0.00")
    )

    total_paid = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=Decimal("0.00")
    )

    credit_limit = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=Decimal("0.00")
    )

    # =========================
    # OPERATIONAL METRICS
    # =========================
    total_items_supplied = models.PositiveIntegerField(default=0)

    last_supply_date = models.DateTimeField(blank=True, null=True)

    payment_terms = models.CharField(
        max_length=50,
        choices=[
            ("cash", "Cash"),
            ("credit", "Credit"),
            ("30_days", "30 Days"),
            ("60_days", "60 Days"),
        ],
        default="cash"
    )

    rating = models.PositiveSmallIntegerField(default=0)

    # =========================
    # SYSTEM FIELDS
    # =========================
    created_at = models.DateTimeField(auto_now_add=True)

    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-created_at"]
        unique_together = ("business", "name")

    def __str__(self):
        return self.name

    # =========================
    # BUSINESS LOGIC HELPERS
    # =========================
    @property
    def balance_due(self):
        return self.total_purchases - self.total_paid

    @property
    def is_over_credit_limit(self):
        return self.balance_due > self.credit_limit


class InventoryStockHistory(models.Model):

    ACTION_CHOICES = [
        ("restock", "Restock"),
        ("sale", "Sale Deduction"),
        ("adjustment", "Manual Adjustment"),
        ('damaged', 'Damaged'),
        ('returned', 'Returned'),
        ('transfer', 'Transfer'),
        ('expired', 'Expired / Disposed'),
    ]

    business = models.ForeignKey(Business, on_delete=models.CASCADE)
    inventory = models.ForeignKey(
        Inventory,
        on_delete=models.CASCADE,
        related_name="history"
    )

    previous_stock = models.IntegerField()
    quantity = models.IntegerField()
    new_stock = models.IntegerField()

    action_type = models.CharField(
        max_length=30,
        choices=ACTION_CHOICES
    )
    reference_number = models.TextField(blank=True, null=True)

    # =====================================================
    # ENTERPRISE RECEIVING INFORMATION
    # =====================================================

    supplier = models.ForeignKey(
        Supplier,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="restocks"
    )

    invoice_number = models.CharField(
        max_length=80,
        blank=True
    )

    purchase_cost = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=0
    )

    warehouse = models.CharField(
        max_length=120,
        blank=True
    )

    reference = models.CharField(
        max_length=120,
        blank=True
    )

    received_date = models.DateField(
        null=True,
        blank=True
    )

    received_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )

    remarks = models.TextField(
        blank=True
    )

    note = models.TextField(blank=True, null=True)

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.inventory.product_name} - {self.action_type}"

    @property
    def total_cost(self):
        return self.purchase_cost * self.quantity

    @property
    def supplier_name(self):
        if self.supplier:
            return self.supplier.name
        return "-"

    @property
    def received_by_name(self):
        if self.received_by:
            return self.received_by.get_full_name() or self.received_by.username
        return "-"

    @property
    def quantity_changed(self):
        return self.quantity

    @property
    def performed_by(self):
        return self.received_by

    def __str__(self):
        return (
            f"{self.inventory.product_name} "
            f"(+{self.quantity}) "
            f"- {self.created_at:%d %b %Y}"
        )

    class Meta:
        ordering = ["-created_at"]
        verbose_name = "Inventory Restock"
        verbose_name_plural = "Inventory Restocks"


class Purchase(models.Model):
    STATUS_CHOICES = (

        ("draft", "Draft"), ("submitted", "Submitted"), ("approved", "Approved"), ("ordered", "Ordered"),
        ("partial", "Partially Received"), ("received", "Fully Received"), ("closed", "Closed"), ("cancelled", "Cancelled"),

    )

    business = models.ForeignKey('business.Business', on_delete=models.CASCADE)
    supplier = models.ForeignKey('Supplier', on_delete=models.CASCADE)
    reference_number = models.CharField(max_length=50, unique=True)

    # =========================
    # FINANCIALS
    # =========================

    subtotal = models.DecimalField(max_digits=12, decimal_places=2,  default=0)
    purchase_discount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    purchase_tax_percent = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    total_cost = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    paid_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    payment_status = models.CharField(max_length=20, choices=[
            ("pending", "Pending"),
            ("partial", "Partial"),
            ("paid", "Paid"),
        ],
        default="pending"
    )

    # =========================
    # PURCHASE WORKFLOW
    # =========================

    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="draft")
    # =====================================================
    # ENTERPRISE PROCUREMENT
    # =====================================================

    purchase_order_number = models.CharField(
        max_length=40,
        unique=True,
        blank=True
    )

    supplier_reference = models.CharField(
        max_length=100,
        blank=True
    )

    buyer = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="purchase_buyer"
    )

    requested_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="purchase_requester"
    )

    approved_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="purchase_approver"
    )

    approved_at = models.DateTimeField(
        null=True,
        blank=True
    )

    ordered_at = models.DateTimeField(
        null=True,
        blank=True
    )

    expected_delivery = models.DateField(
        null=True,
        blank=True
    )

    warehouse = models.CharField(
        max_length=120,
        blank=True
    )

    delivery_address = models.TextField(
        blank=True
    )
    priority = models.CharField(max_length=20,
        choices=[
            ("Low", "Low"),
            ("Normal", "Normal"),
            ("High", "High"),
            ("Urgent", "Urgent"),
        ],
        default="Normal"
    )

    is_approved = models.BooleanField(default=False)

    approval_notes = models.TextField(blank=True)

    internal_notes = models.TextField(blank=True)

    created_by = models.ForeignKey(
        'auth.User',
        on_delete=models.SET_NULL,
        null=True
    )

    created_at = models.DateTimeField(
        auto_now_add=True
    )

    def __str__(self):
        return self.reference_number

    @property
    def balance(self):

        balance = (
                self.total_cost -
                self.paid_amount
        )

        return max(
            balance,
            Decimal("0.00")
        )

    @property
    def amount_due(self):

        return self.balance

    @property
    def payment_percentage(self):

        if self.total_cost <= 0:
            return Decimal("0")

        return round(
            (
                    self.paid_amount /
                    self.total_cost
            ) * 100,
            2
        )

    @property
    def total_items(self):
        return self.items.count()

    @property
    def total_quantity(self):
        return sum(
            item.quantity
            for item in self.items.all()
        )

    @property
    def total_received(self):
        return sum(
            item.received_quantity
            for item in self.items.all()
        )

    def calculate_totals(
            self,
            purchase_discount=None,
            purchase_tax=None
    ):

        subtotal = Decimal("0.00")

        for item in self.items.all():
            subtotal += (
                    item.total_cost or Decimal("0.00")
            )

        # Use provided values or existing values
        if purchase_discount is None:
            purchase_discount = (
                    self.purchase_discount or Decimal("0.00")
            )

        if purchase_tax is None:
            purchase_tax = (
                    self.purchase_tax_percent or Decimal("0.00")
            )

        purchase_discount = Decimal(
            str(purchase_discount)
        )

        purchase_tax = Decimal(
            str(purchase_tax)
        )

        # Prevent discount exceeding subtotal
        if purchase_discount > subtotal:
            purchase_discount = subtotal

        taxable_amount = (
                subtotal - purchase_discount
        )

        tax_amount = (
                taxable_amount *
                purchase_tax /
                Decimal("100")
        )

        grand_total = (
                taxable_amount +
                tax_amount
        )

        self.subtotal = subtotal
        self.purchase_discount = purchase_discount
        self.purchase_tax_percent = purchase_tax
        self.total_cost = grand_total

        self.save(
            update_fields=[
                "subtotal",
                "purchase_discount",
                "purchase_tax_percent",
                "total_cost",
            ]
        )

        return grand_total

    def post_purchase(self, user=None):

        with transaction.atomic():

            for item in self.items.all():

                inventory = item.product

                previous_stock = inventory.stock_quantity
                new_stock = previous_stock + item.quantity

                inventory.stock_quantity = new_stock
                inventory.save()

                InventoryStockHistory.objects.create(
                    business=self.business,
                    inventory=inventory,
                    previous_stock=previous_stock,
                    quantity=item.quantity,  # was quantity_changed (invalid field)
                    new_stock=new_stock,
                    action_type="restock",
                    received_by=user,  # was performed_by (invalid field)
                    supplier=self.supplier,
                    reference_number=self.reference_number,
                    remarks=f"Purchase received: {self.reference_number}",
                )

                # NEW — auto-create an expiry-tracked batch if this line
                # had an expiry date captured at purchase time.
                if not self.purchase_order_number:
                    self.purchase_order_number = (
                            "PO-" +
                            uuid.uuid4().hex[:8].upper()
                    )

                if item.expiry_date:
                    ProductBatch.objects.create(
                        business=self.business,
                        product=inventory,
                        purchase=self,
                        quantity=item.quantity,
                        cost_price=item.unit_cost,
                        expiry_date=item.expiry_date,
                        supplier=self.supplier,
                        received_date=timezone.now().date(),
                        notes=f"Auto-created from purchase {self.reference_number}",
                    )

            self.status = "received"
            self.save(update_fields=["status"])

            supplier = self.supplier

            supplier.total_purchases += (
                    self.total_cost or Decimal("0.00")
            )

            supplier.total_items_supplied += sum(
                i.quantity
                for i in self.items.all()
            )

            supplier.last_supply_date = timezone.now()

            supplier.save()


    # def post_purchase(self, user=None):
    #
    #     with transaction.atomic():
    #
    #         for item in self.items.all():
    #
    #             inventory = item.product
    #
    #             previous_stock = inventory.stock_quantity
    #             new_stock = previous_stock + item.quantity
    #
    #             inventory.stock_quantity = new_stock
    #             inventory.save()
    #
    #             InventoryStockHistory.objects.create(
    #                 business=self.business,
    #                 inventory=inventory,
    #                 previous_stock=previous_stock,
    #                 quantity_changed=item.quantity,
    #                 new_stock=new_stock,
    #                 action_type="restock",
    #                 performed_by=user,
    #                 reference_number=self.reference_number,
    #                 note=f"Purchase received: {self.reference_number}"
    #             )
    #
    #         self.status = "received"
    #         self.save(update_fields=["status"])
    #
    #         supplier = self.supplier
    #
    #         supplier.total_purchases += (
    #             self.total_cost or Decimal("0.00")
    #         )
    #
    #         supplier.total_items_supplied += sum(
    #             i.quantity
    #             for i in self.items.all()
    #         )
    #
    #         supplier.last_supply_date = timezone.now()
    #
    #         supplier.save()


class PurchaseItem(models.Model):

    purchase = models.ForeignKey(Purchase, on_delete=models.CASCADE, related_name="items", null=True)
    product = models.ForeignKey('Inventory', on_delete=models.CASCADE, null=True)
    quantity = models.PositiveIntegerField()
    unit_cost = models.DecimalField(max_digits=12, decimal_places=2)
    discount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    tax_percent = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    total_cost = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    expiry_date = models.DateField(null=True, blank=True)

    def save(self, *args, **kwargs):

        qty = Decimal(str(self.quantity))
        unit_cost = Decimal(str(self.unit_cost))
        discount = Decimal(str(self.discount or 0))
        tax_percent = Decimal(str(self.tax_percent or 0))

        # subtotal
        subtotal = qty * unit_cost

        # prevent negative values
        if discount > subtotal:
            discount = subtotal

        after_discount = subtotal - discount

        tax_amount = (
            after_discount *
            (tax_percent / Decimal("100"))
        )

        self.total_cost = (
            after_discount +
            tax_amount
        )

        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.product.product_name}"


class SupplierPayment(models.Model):

    supplier = models.ForeignKey(
        'Supplier',
        on_delete=models.CASCADE
    )

    purchase = models.ForeignKey(
        Purchase,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name="payments"
    )

    amount_paid = models.DecimalField(
        max_digits=12,
        decimal_places=2
    )

    payment_method = models.CharField(
        max_length=20,
        choices=[
            ("cash", "Cash"),
            ("bank", "Bank Transfer"),
            ("mobile_money", "Mobile Money"),
        ]
    )

    # Auto-generated system payment number
    reference = models.CharField(
        max_length=50,
        unique=True,
        blank=True,
        null=True
    )

    # Optional user-entered bank/MoMo transaction ID
    external_reference = models.CharField(
        max_length=50,
        blank=True,
        null=True
    )

    note = models.TextField(
        blank=True,
        null=True
    )

    created_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )

    created_at = models.DateTimeField(
        auto_now_add=True
    )

    def generate_reference(self):

        today = timezone.now().strftime(
            "%Y%m%d"
        )

        last_payment = SupplierPayment.objects.filter(
            reference__startswith=f"SP-{today}"
        ).order_by(
            "-id"
        ).first()

        if last_payment:

            try:

                last_no = int(
                    last_payment.reference.split("-")[-1]
                )

            except:

                last_no = 0

        else:

            last_no = 0

        next_no = str(
            last_no + 1
        ).zfill(5)

        return f"SP-{today}-{next_no}"

    def save(self,*args,**kwargs):

        is_new = self.pk is None

        # Generate payment reference automatically
        if not self.reference:

            self.reference = (
                self.generate_reference()
            )

        super().save(*args,**kwargs)

        if is_new and self.purchase:

            purchase = self.purchase

            purchase.paid_amount += (
                self.amount_paid
            )

            # Prevent overpayment

            if purchase.paid_amount > purchase.total_cost:

                purchase.paid_amount = (
                    purchase.total_cost
                )


            if purchase.paid_amount <= 0:

                purchase.payment_status = (
                    "pending"
                )

            elif purchase.paid_amount >= purchase.total_cost:

                purchase.payment_status = (
                    "paid"
                )

            else:

                purchase.payment_status = (
                    "partial"
                )

            purchase.save(
                update_fields=[
                    "paid_amount",
                    "payment_status"
                ]
            )

    def __str__(self):

        return self.reference


class ProductBatch(models.Model):

    STATUS_CHOICES = [
        ("active", "Active"),
        ("disposed", "Disposed"),
    ]

    # Thresholds for expiry_status — kept as class constants so both the
    # model and views/templates agree on the same cutoffs. Adjust here
    # if you want them configurable per business later.
    NEAR_EXPIRY_WARNING_DAYS = 30
    NEAR_EXPIRY_CRITICAL_DAYS = 7

    business = models.ForeignKey(Business, on_delete=models.CASCADE, related_name="product_batches")
    product = models.ForeignKey(Inventory, on_delete=models.CASCADE, related_name="batches")
    purchase = models.ForeignKey(
        'Purchase', on_delete=models.SET_NULL, null=True, blank=True,
        related_name="batches_created"
    )

    batch_number = models.CharField(max_length=60, blank=True)

    quantity = models.PositiveIntegerField()
    initial_quantity = models.PositiveIntegerField(default=0)

    cost_price = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0.00"))

    manufacture_date = models.DateField(null=True, blank=True)
    expiry_date = models.DateField(db_index=True)

    supplier = models.ForeignKey(
        Supplier, on_delete=models.SET_NULL, null=True, blank=True, related_name="product_batches"
    )

    received_date = models.DateField(default=timezone.now)

    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="active")

    disposed_quantity = models.PositiveIntegerField(default=0)
    disposed_at = models.DateTimeField(null=True, blank=True)
    disposed_by = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, blank=True, related_name="+"
    )
    disposal_reason = models.TextField(blank=True)

    notes = models.TextField(blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["expiry_date"]
        unique_together = ("business", "batch_number")
        verbose_name = "Product Batch"
        verbose_name_plural = "Product Batches"

    def save(self, *args, **kwargs):
        if not self.batch_number:
            self.batch_number = f"BATCH-{uuid.uuid4().hex[:8].upper()}"
        if not self.initial_quantity:
            self.initial_quantity = self.quantity
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.product.product_name} — {self.batch_number}"

    # =========================
    # EXPIRY LOGIC
    # =========================
    @property
    def days_to_expiry(self):
        return (self.expiry_date - timezone.now().date()).days

    @property
    def is_expired(self):
        return self.days_to_expiry < 0

    @property
    def expiry_status(self):
        """One of: disposed, expired, critical, warning, healthy."""
        if self.status == "disposed":
            return "disposed"

        days = self.days_to_expiry

        if days < 0:
            return "expired"
        if days <= self.NEAR_EXPIRY_CRITICAL_DAYS:
            return "critical"
        if days <= self.NEAR_EXPIRY_WARNING_DAYS:
            return "warning"
        return "healthy"

    @property
    def batch_value(self):
        return self.quantity * self.cost_price

    @property
    def supplier_name(self):
        return self.supplier.name if self.supplier else "-"


class InventoryMovement(models.Model):

    business = models.ForeignKey(
        Business,
        on_delete=models.CASCADE,
        related_name="inventory_movements"
    )

    product = models.ForeignKey(
        Inventory,
        on_delete=models.CASCADE,
        related_name="movements"
    )

    movement_type = models.CharField(
        max_length=20,
        choices=MOVEMENT_TYPES
    )

    quantity = models.PositiveIntegerField()

    before_quantity = models.PositiveIntegerField(default=0)

    after_quantity = models.PositiveIntegerField(default=0)

    unit_cost = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=Decimal("0.00")
    )

    total_cost = models.DecimalField(
        max_digits=14,
        decimal_places=2,
        default=Decimal("0.00")
    )

    reference = models.CharField(
        max_length=100,
        blank=True
    )

    notes = models.TextField(
        blank=True
    )

    created_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True
    )

    created_at = models.DateTimeField(
        auto_now_add=True
    )

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.product} - {self.movement_type}"


# Enterprise procurement models - append these to inventory/models.py
# from django.db import models, transaction
# from django.utils import timezone
# from decimal import Decimal
# import uuid

# Assumes Business, Supplier, Inventory, Purchase, PurchaseItem, ProductBatch,
# InventoryStockHistory are defined earlier in inventory/models.py

PO_STATUS_CHOICES = [
    ("draft", "Draft"),
    ("issued", "Issued"),
    ("partially_received", "Partially Received"),
    ("received", "Received"),
    ("cancelled", "Cancelled"),
]

GRN_STATUS_CHOICES = [
    ("draft", "Draft"),
    ("received", "Received"),
    ("cancelled", "Cancelled"),
]


def _generate_po_reference():
    ts = timezone.now().strftime("%Y%m%d%H%M%S")
    suffix = uuid.uuid4().hex[:4].upper()
    return f"PO-{ts}-{suffix}"


def _generate_grn_reference():
    ts = timezone.now().strftime("%Y%m%d%H%M%S")
    suffix = uuid.uuid4().hex[:4].upper()
    return f"GRN-{ts}-{suffix}"


class PurchaseOrder(models.Model):
    """Purchase Order (procurement request/authority)."""
    business = models.ForeignKey('business.Business', on_delete=models.CASCADE)
    supplier = models.ForeignKey('Supplier', on_delete=models.CASCADE)
    reference_number = models.CharField(max_length=60, unique=True, default=_generate_po_reference)
    expected_date = models.DateField(null=True, blank=True)
    notes = models.TextField(blank=True)
    status = models.CharField(max_length=30, choices=PO_STATUS_CHOICES, default="draft")
    created_by = models.ForeignKey('auth.User', on_delete=models.SET_NULL, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    @property
    def total_cost(self):
        return sum((i.total_cost or Decimal("0.00")) for i in self.items.all())

    def __str__(self):
        return self.reference_number


class PurchaseOrderItem(models.Model):
    po = models.ForeignKey(PurchaseOrder, on_delete=models.CASCADE, related_name="items")
    product = models.ForeignKey('Inventory', on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField()
    unit_cost = models.DecimalField(max_digits=12, decimal_places=2)
    discount = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0.00"))
    tax_percent = models.DecimalField(max_digits=5, decimal_places=2, default=Decimal("0.00"))
    total_cost = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal("0.00"))
    expected_delivery_date = models.DateField(null=True, blank=True)
    expiry_date = models.DateField(null=True, blank=True)

    def save(self, *args, **kwargs):
        qty = Decimal(str(self.quantity))
        unit_cost = Decimal(str(self.unit_cost))
        discount = Decimal(str(self.discount or 0))
        tax_percent = Decimal(str(self.tax_percent or 0))

        subtotal = qty * unit_cost
        if discount > subtotal:
            discount = subtotal
        after_discount = subtotal - discount
        tax_amount = (after_discount * (tax_percent / Decimal("100")))
        self.total_cost = after_discount + tax_amount

        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.product.product_name} x{self.quantity} ({self.po.reference_number})"


class GoodsReceipt(models.Model):
    """Goods receiving document (GRN). Optionally links back to a PO and creates a Purchase (invoice)."""
    business = models.ForeignKey('business.Business', on_delete=models.CASCADE)
    purchase_order = models.ForeignKey(PurchaseOrder, on_delete=models.SET_NULL, null=True, blank=True, related_name="receipts")
    purchase = models.ForeignKey('Purchase', on_delete=models.SET_NULL, null=True, blank=True, related_name="goods_receipts")
    receipt_number = models.CharField(max_length=60, unique=True, default=_generate_grn_reference)
    received_by = models.ForeignKey('auth.User', on_delete=models.SET_NULL, null=True, blank=True)
    received_at = models.DateTimeField(default=timezone.now)
    notes = models.TextField(blank=True)
    status = models.CharField(max_length=30, choices=GRN_STATUS_CHOICES, default="draft")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return self.receipt_number


class GoodsReceiptItem(models.Model):
    grn = models.ForeignKey(GoodsReceipt, on_delete=models.CASCADE, related_name="items")
    product = models.ForeignKey('Inventory', on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField()
    unit_cost = models.DecimalField(max_digits=12, decimal_places=2)
    total_cost = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal("0.00"))
    expiry_date = models.DateField(null=True, blank=True)

    def save(self, *args, **kwargs):
        self.total_cost = Decimal(str(self.quantity)) * Decimal(str(self.unit_cost))
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.product.product_name} x{self.quantity} ({self.grn.receipt_number})"


LABEL_CODE_TYPES = (
    ("barcode", "Barcode (CODE128)"),
    ("qrcode", "QR Code"),
)


class LabelTemplate(models.Model):
    """A reusable label layout/size preset for barcode & price-tag printing."""

    business = models.ForeignKey(
        Business, on_delete=models.CASCADE, related_name="label_templates"
    )
    name = models.CharField(max_length=80)
    code_type = models.CharField(max_length=10, choices=LABEL_CODE_TYPES, default="barcode")

    # Physical label size, in millimetres — drives the print CSS directly,
    # since mm is a valid CSS unit and prints accurately across browsers.
    width_mm = models.PositiveIntegerField(default=40)
    height_mm = models.PositiveIntegerField(default=30)
    columns = models.PositiveIntegerField(default=3, help_text="Labels per row on the print sheet")
    gap_mm = models.PositiveIntegerField(default=2, help_text="Gap between labels, in mm")

    # Which fields to print on each label
    show_business_name = models.BooleanField(default=False)
    show_product_name = models.BooleanField(default=True)
    show_price = models.BooleanField(default=True)
    show_sku = models.BooleanField(default=True)

    is_default = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-is_default", "name"]
        unique_together = ("business", "name")

    def __str__(self):
        return f"{self.name} ({self.width_mm}\u00d7{self.height_mm}mm)"

    def save(self, *args, **kwargs):
        # Only one default template per business at a time
        if self.is_default:
            LabelTemplate.objects.filter(
                business=self.business, is_default=True
            ).exclude(pk=self.pk).update(is_default=False)
        super().save(*args, **kwargs)


class LabelPrintLog(models.Model):
    """Audit trail of label print runs — who printed what, and how many."""

    business = models.ForeignKey(
        Business, on_delete=models.CASCADE, related_name="label_print_logs"
    )
    product = models.ForeignKey(
        Inventory, on_delete=models.CASCADE, related_name="label_print_logs"
    )
    template = models.ForeignKey(
        LabelTemplate, on_delete=models.SET_NULL, null=True, blank=True
    )
    quantity = models.PositiveIntegerField(default=1)
    printed_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    printed_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-printed_at"]

    def __str__(self):
        return f"{self.product.product_name} x{self.quantity} ({self.printed_at:%Y-%m-%d})"


class Warehouse(models.Model):
    business = models.ForeignKey(
        Business,
        on_delete=models.CASCADE,
        related_name="warehouses"
    )
    name = models.CharField(max_length=100)
    code = models.CharField(max_length=20, blank=True)
    location = models.CharField(max_length=255, blank=True)
    phone = models.CharField(max_length=30, blank=True)
    is_default = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-is_default", "name"]
        unique_together = ("business", "name")

    def save(self, *args, **kwargs):
        if not self.code:
            self.code = f"WH-{uuid.uuid4().hex[:6].upper()}"
        # Only one default warehouse per business at a time
        if self.is_default:
            Warehouse.objects.filter(
                business=self.business, is_default=True
            ).exclude(pk=self.pk).update(is_default=False)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.name


class WarehouseStock(models.Model):
    """Per-warehouse stock level for a product. See the design note above —
    the sum of a product's rows here should always equal its
    Inventory.stock_quantity."""

    business = models.ForeignKey(
        Business,
        on_delete=models.CASCADE,
        related_name="warehouse_stocks"
    )
    warehouse = models.ForeignKey(Warehouse, on_delete=models.CASCADE, related_name="stock_levels")
    product = models.ForeignKey(
        Inventory,
        on_delete=models.CASCADE,
        related_name="warehouse_stocks"
    )
    quantity = models.PositiveIntegerField(default=0)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ("warehouse", "product")
        ordering = ["warehouse__name"]

    def __str__(self):
        return f"{self.product.product_name} @ {self.warehouse.name}: {self.quantity}"


TRANSFER_STATUS_CHOICES = [
    ("draft", "Draft"),
    ("in_transit", "In Transit"),
    ("completed", "Completed"),
    ("cancelled", "Cancelled"),
]


def _generate_transfer_reference():
    ts = timezone.now().strftime("%Y%m%d%H%M%S")
    suffix = uuid.uuid4().hex[:4].upper()
    return f"TRF-{ts}-{suffix}"


class StockTransfer(models.Model):
    """A transfer of stock between two warehouses of the same business.
    Two-step workflow, mirroring the existing PurchaseOrder -> GoodsReceipt
    pattern already used elsewhere in this app:

      draft -> dispatch() -> in_transit -> receive() -> completed
                                         \\-> cancel() -> cancelled

    dispatch() deducts stock from the source warehouse; receive() adds it
    to the destination warehouse. A draft can be cancelled with no stock
    impact; an in_transit transfer can be cancelled too, and doing so
    restocks the source (since the goods never left, so to speak).
    """

    business = models.ForeignKey(Business, on_delete=models.CASCADE, related_name="stock_transfers")
    reference_number = models.CharField(max_length=60, unique=True, default=_generate_transfer_reference)

    source_warehouse = models.ForeignKey(
        Warehouse, on_delete=models.CASCADE, related_name="outgoing_transfers"
    )
    destination_warehouse = models.ForeignKey(
        Warehouse, on_delete=models.CASCADE, related_name="incoming_transfers"
    )

    status = models.CharField(max_length=20, choices=TRANSFER_STATUS_CHOICES, default="draft")
    notes = models.TextField(blank=True)

    requested_by = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, blank=True, related_name="transfers_requested"
    )
    dispatched_by = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, blank=True, related_name="transfers_dispatched"
    )
    received_by = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, blank=True, related_name="transfers_received"
    )

    dispatched_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return self.reference_number

    def clean(self):
        if (
            self.source_warehouse_id
            and self.destination_warehouse_id
            and self.source_warehouse_id == self.destination_warehouse_id
        ):
            raise ValidationError("Source and destination warehouse must be different.")

    @property
    def total_quantity(self):
        return sum(i.quantity for i in self.items.all())

    @property
    def total_items(self):
        return self.items.count()

    def dispatch(self, user=None):
        """draft -> in_transit: deduct stock from the source warehouse."""
        if self.status != "draft":
            raise ValueError("Only draft transfers can be dispatched.")

        with transaction.atomic():
            for item in self.items.select_related("product"):
                source_stock, _ = WarehouseStock.objects.get_or_create(
                    business=self.business, warehouse=self.source_warehouse, product=item.product,
                    defaults={"quantity": 0},
                )
                if source_stock.quantity < item.quantity:
                    raise ValueError(
                        f"Not enough stock of {item.product.product_name} at "
                        f"{self.source_warehouse.name} (have {source_stock.quantity}, "
                        f"need {item.quantity})."
                    )
                before = source_stock.quantity
                source_stock.quantity -= item.quantity
                source_stock.save(update_fields=["quantity", "updated_at"])

                InventoryMovement.objects.create(
                    business=self.business, product=item.product, movement_type="transfer_out",
                    quantity=item.quantity, before_quantity=before, after_quantity=source_stock.quantity,
                    reference=self.reference_number,
                    notes=f"Transfer to {self.destination_warehouse.name}",
                    created_by=user,
                )

            self.status = "in_transit"
            self.dispatched_by = user
            self.dispatched_at = timezone.now()
            self.save(update_fields=["status", "dispatched_by", "dispatched_at"])

    def receive(self, user=None):
        """in_transit -> completed: add stock to the destination warehouse."""
        if self.status != "in_transit":
            raise ValueError("Only in-transit transfers can be received.")

        with transaction.atomic():
            for item in self.items.select_related("product"):
                dest_stock, _ = WarehouseStock.objects.get_or_create(
                    business=self.business, warehouse=self.destination_warehouse, product=item.product,
                    defaults={"quantity": 0},
                )
                before = dest_stock.quantity
                dest_stock.quantity += item.quantity
                dest_stock.save(update_fields=["quantity", "updated_at"])

                InventoryMovement.objects.create(
                    business=self.business, product=item.product, movement_type="transfer_in",
                    quantity=item.quantity, before_quantity=before, after_quantity=dest_stock.quantity,
                    reference=self.reference_number,
                    notes=f"Transfer from {self.source_warehouse.name}",
                    created_by=user,
                )

            self.status = "completed"
            self.received_by = user
            self.completed_at = timezone.now()
            self.save(update_fields=["status", "received_by", "completed_at"])

    def cancel(self, user=None):
        """Cancel a draft or in-transit transfer. If it was already
        dispatched, restock the source warehouse."""
        if self.status not in ("draft", "in_transit"):
            raise ValueError("Only draft or in-transit transfers can be cancelled.")

        with transaction.atomic():
            if self.status == "in_transit":
                for item in self.items.select_related("product"):
                    source_stock, _ = WarehouseStock.objects.get_or_create(
                        business=self.business, warehouse=self.source_warehouse, product=item.product,
                        defaults={"quantity": 0},
                    )
                    before = source_stock.quantity
                    source_stock.quantity += item.quantity
                    source_stock.save(update_fields=["quantity", "updated_at"])

                    InventoryMovement.objects.create(
                        business=self.business, product=item.product, movement_type="adjustment",
                        quantity=item.quantity, before_quantity=before, after_quantity=source_stock.quantity,
                        reference=self.reference_number,
                        notes=f"Transfer {self.reference_number} cancelled \u2014 restocked at "
                              f"{self.source_warehouse.name}",
                        created_by=user,
                    )

            self.status = "cancelled"
            self.save(update_fields=["status"])


class StockTransferItem(models.Model):
    transfer = models.ForeignKey(StockTransfer, on_delete=models.CASCADE, related_name="items")
    product = models.ForeignKey(Inventory, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField()
    notes = models.CharField(max_length=255, blank=True)

    def __str__(self):
        return f"{self.product.product_name} x{self.quantity} ({self.transfer.reference_number})"

